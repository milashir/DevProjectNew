﻿using System;

namespace Businesslayer
{
    public class Class1
    {
    }
}
