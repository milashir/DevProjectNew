EF1 is an ASP.NET MVC 5 (Razor) CRUD (Create Read Update Delete) web application that uses EF6 (Entity Framework 6) as an ORM (Object Relational Mapper) to a Database First SQL Server database.  Using the Visual Studio IDE, I was able to create this using only ONE edit*; the rest of the input was from using the VS dialogs!
*The single edit was just to change the default routing from the HomeController to the UsersController.

1) Create Test001 database, add the schema, and populate the database (see SQL folder).
2) Build and run the solution.