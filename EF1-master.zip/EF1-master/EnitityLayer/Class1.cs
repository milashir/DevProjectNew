﻿using System;

namespace EnitityLayer
{
    public class Class1
    {
    }
}
