﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Businesslayer;
using EnitityLayer;
using EF1.Models;
using System.Net;
using Newtonsoft.Json;

namespace EF1.Controllers
{
    public class HomeController : Controller
    {
        BLLDev objBLLDev = new BLLDev();

        public ActionResult Index()
        {
            //string json = string.Empty;
            //using (var client = new WebClient())
            //{
            //     json = client.DownloadString("https://jsonplaceholder.typicode.com/posts");
            //}
            //JsonModel [] jsonModels = JsonConvert.DeserializeObject<JsonModel[]>(json);
            //jsonModels = jsonModels.Where(x => x.body.Contains("minima")).OrderBy(x => x.id).ToArray();
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
       
    }
}