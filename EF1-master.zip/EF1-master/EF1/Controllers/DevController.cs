﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using EnitityLayer;
using Businesslayer;
using System.Web.Mvc;
using EF1.Models;

using Newtonsoft.Json;
using System.Net.Http.Headers;
using System.Text;

namespace EF1.Controllers
{
    public class DevController : ApiController
    {
        BLLDev objBLLDev = new BLLDev();

        /// <summary>
        /// Return lstProductModel in Json
        /// </summary>
        /// <returns>List<ProductModel></returns>
        [System.Web.Mvc.Route("api/Product/GetJsonData")]
        public HttpResponseMessage GetJsonData()
        {
            string json = string.Empty;
            using (var client = new WebClient())
            {
                json = client.DownloadString("https://jsonplaceholder.typicode.com/posts");
            }
            JsonModel[] jsonModels = JsonConvert.DeserializeObject<JsonModel[]>(json);
            jsonModels = jsonModels.Where(x => x.body.Contains("minima")).OrderBy(x => x.id).ToArray();
            var response = Request.CreateResponse(HttpStatusCode.OK, jsonModels, MediaTypeHeaderValue.Parse("application/json"));
            return response;
        }

        /// <summary>
        /// Return lstProductModel in Json
        /// </summary>
        /// <returns>List<ProductModel></returns>
        [System.Web.Mvc.Route("api/Product/ProductList")]
        public HttpResponseMessage GetProductDetails()
        {
            List<Product> lstProduct = objBLLDev.GetAllProducts();
            List<ProductModel> lstProductModel = ConvertProductEntityToModel(lstProduct);
            var response = Request.CreateResponse(HttpStatusCode.OK, lstProductModel, MediaTypeHeaderValue.Parse("application/json"));
            return response;
        }

        /// <summary>
        /// Return lstProductModel in Json
        /// </summary>
        /// <returns>List<ProductModel></returns>
        [System.Web.Mvc.Route("api/Product/GetProduct")]
        public HttpResponseMessage GetProductByIdandQuantity([FromBody] ProductModel product)
        {
            List<Product> lstProduct = objBLLDev.GetProductByIdandQuantity(product.ProductId, product.quantity);
            List<ProductModel> lstProductModel = (lstProduct != null) ? ConvertProductEntityToModel(lstProduct) : null;
            var response = Request.CreateResponse(HttpStatusCode.OK, lstProductModel, MediaTypeHeaderValue.Parse("application/json"));
            return response;
        }

        /// <summary>
        /// Convert product entity to model
        /// </summary>
        /// <param name="lstProduct"></param>
        /// <returns>List<Product></returns>
        public List<ProductModel> ConvertProductEntityToModel(List<Product> lstProduct)
        {
            List<ProductModel> lstProductModel = new List<ProductModel>();
            foreach (Product product in lstProduct)
            {
                ProductModel productModel = new ProductModel();
                productModel.Id = product.Id;
                productModel.ProductId = product.ProductId;
                productModel.ProductName = product.ProductName;
                productModel.StockAvailable = product.StockAvailable;
                lstProductModel.Add(productModel);
            }
            return lstProductModel;
        }
    }
}
