﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EF1.Models
{
    public class JsonModel
    {
        public int userId;
        public int id;
        public string title;
        public string body;
    }
}