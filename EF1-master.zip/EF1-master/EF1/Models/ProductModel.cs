﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EF1.Models
{
    public class ProductModel
    {
        public int Id;

        public int ProductId;

        public string ProductName;

        public int StockAvailable;
        public int quantity;
    }
}